
<?php
echo "<pre>";
/*
Devin Tems
PHP Programming
05-30-17
Hello Functions
*/

$studentName = ucfirst("devin tems");
echo $studentName;

function fix_name($n)
{
	$n = ucwords(strtolower($n));
	return $n;
}

//class definition of PotentialUser
class PotentialUser
{ // list of variables need for the class
  public $userName = NULL;
  public $firstName = NULL;
  public $lastName = NULL;
  public $password = NULL;
  public $phoneNum = NULL;
  public $email = NULL;
  public $address = NULL;
//constructor method
  function __construct($a, $b, $c, $d, $e, $f, $g)
  {
    $this -> userName = $a;
    $this -> firstName = $b;
    $this -> lastName = $c;
    $this -> password = $d;
    $this -> phoneNum = $e;
    $this -> email = $f;
    $this -> address = $g;
  }
};
//end of class PotentialUser
//Begining of definition of EnrolledUser Class
class EnrolledUser extends PotentialUser
{
//list of variables needed for the class
  public $nameOfClass = NULL;
  public $subjectOfClass = NULL;
  public $instructorName = NULL;
//List of function
//constructor for object when declared and wish to initialize the variables of the class
  function __construct($a, $b, $c, $d, $e, $f, $g, $h, $i, $j)
  {
    $this -> nameOfClass = $a;
    $this -> subjectOfClass = $b;
    $this -> instructorName = $c;
    parent::__construct($d, $e, $f, $g, $h, $i, $j);
  }
};
//end of class file
echo "</pre>";
?>
