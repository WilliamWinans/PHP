<?php
echo "<pre>";

/*
Devin Tems
PHP Programming
05-30-17
Hello Functions
*/

include_once('CH5_DevinTems_HelloFunctions.php');

$studentName = "dEVIN tEMS";

echo fix_name($studentName) . "<br>" . PHP_EOL;

$user = new PotentialUser("Darkrious", "Devin", "Tems", "ABcd1234", "903-666-2323", "dctems@mymail.tstc.edu", "18007 fm 449, Hallsville,Tx, 75650");
$enrolledUser = new EnrolledUser("ITSE 1306","PHP Programming", "Will Winans", "Darkrious", "Devin", "Tems", "ABcd1234", "903-666-2323", "dctems@mymail.tstc.edu", "18007 fm 449, Hallsville,Tx", "75650");

print_r($user);
print_r($enrolledUser);
echo "</pre>";
?>
