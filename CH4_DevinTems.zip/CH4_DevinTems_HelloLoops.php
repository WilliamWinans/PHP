<?php
/*
Devin Tems
PHP Programming 
May 5, 2017
Hello Loops
*/
//A html format tag that 'creates' the standard html framework for php 
echo '<pre>';
//A variable created and printed to the user to show who created it
$studentName = "Devin Tems";
echo $studentName . PHP_EOL;
//An array of the alphabet
$data = array(array('A', 'a'), array('B', 'b'), array('C', 'c'), array('D', 'd'), array('E','e'), array('F', 'f'), array('G', 'g'), 
              array('H', 'h'), array('I', 'i'), array('J','j'), array('K','k'), array('L', 'l'), array('M', 'm'), array('N','n'), array('O','o'),
              array('P','p'), array('Q','q'), array ('R','r'), array('S','s'), array('T','t'), array('U','u'), array('V','v'), array('W','w'), array('X','x'), array('Y', 'y'), array('Z','z'));
//List of variables needed for the loops lower down the page
$count = 0;
$secCount = 0;
$thirdCount = 0;
$fourthCount = 0;
$fifthCount = 0;
//A loop statement that goes through the array of the alphabet
while($count < 26)
{
    echo $data[$count][$secCount] . ", " . $data[$count][$secCount += 1] . "." . PHP_EOL;
    $secCount--;
    $count++;
}
//Whitespace
echo "" . PHP_EOL;
//An alternate loop statement that cycles through the array of the alphabet
do 
{
    echo $data[$thirdCount][$fourthCount] . ", " . $data[$thirdCount][$fourthCount += 1] . "." . PHP_EOL;
    $fourthCount--;
    $thirdCount++;
} while ($thirdCount < 26);
//Whitespace
echo "" . PHP_EOL;
//A for loop statement that cycles through the array fo the alphabet
for($num = 0; $num < 26; $num++)
{
    echo $data[$num][$fifthCount] . "," . $data[$num][$fifthCount += 1] . "." .PHP_EOL;
    $fifthCount--;
}
//End the html format tag
echo '</pre>';
    
?>