<?php
/* 
Devin Tems
PHP Programming
May 21, 2017
Hello Conditionals
*/

echo '<pre>';
//List of variables that is needed for these simple examples of a decision structures
$studentName = "Devin Tems";
$rock = "rock";
//Testing the variables to see if the values are accurately assign to the variables
echo $studentName . PHP_EOL;
echo $rock . PHP_EOL;

//If statement created to see if if statement is coded correctly by  using the date() function to show the user what day it is. 
if (date("l") === "Sunday")
{
    echo "Today is Sunday." . PHP_EOL;
}
elseif (date("l") === "Monday")
{
    echo "Today is Monday" . PHP_EOL;
}
elseif (date("l") === "Tuesday")
{
    echo "Today is Tuesday" . PHP_EOL;
}
elseif (date("l") === "Wednesday")
{
    echo "Today is Wednesday" . PHP_EOL;
}
elseif (date("l") === "Thursday")
{
    echo "Today is Thursday" . PHP_EOL;
}
elseif(date("l") === "Friday")
{
    echo "Today is Friday" . PHP_EOL;
}
elseif(date("l") === "Saturday")
{
    echo "Today is Saturday" . PHP_EOL;
}
else
{
    echo "The date function did not return a value equal to the decision control." . PHP_EOL;
};

//Example of switch statement showing if the winner chose rock in a Rock, Paper, Scissors game
switch ($rock)
{
    case 'paper':
        echo "Paper beats Rock." .PHP_EOL;
        break;
    case 'scissors':
        echo "Scissors cuts Paper." . PHP_EOL;
        break;
    case 'rock':
        echo "Paper crushes Scissors." . PHP_EOL;
        break;
    default:
        echo "The switch statement did not execute properly. Must check code " .PHP_EOL;
};
echo '</pre>';
?>