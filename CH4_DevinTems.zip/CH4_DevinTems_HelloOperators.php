<?php
echo '<pre>';
/*
Devin Tems 
PHP Programming
05-23-2017
Hello Operators
*/

$studnetName = "Devin Tems";
echo $studentName . PHP_EOL;

$random = "Random";
$var = 5;
$varOne = 5;
$varTwo = 5;
$varThree = $var + $varOne *$varTwo;

echo $varThree.PHP_EOL;

echo " " . PHP_EOL;

$varFour = $var == varTwo;

echo " " . PHP_EOL;

echo $varFour . PHP_EOL;

echo "" . PHP_EOL;

echo ++$varTwo . ", " . --$varThree . PHP_EOL;

echo "" . PHP_EOL;

echo $random . ", " . $var . PHP_EOL;

echo "" . PHP_EOL;

if(5 < 10)
{
    echo true . PHP_EOL;
}
if(10 > 5)
{
    echo true . PHP_EOL;
}
if($var <= $varOne)
{
    echo true . PHP_EOL;
}
if($var == $varOne)
{
    echo true . PHP_EOL;
}
if ($var === $varOne)
{
    echo true . PHP_EOL;
}
if($varTwo != $varThree)
{
    echo true . PHP_EOL;
}
if($varTwo !== $varThree)
{
    echo true . PHP_EOL;
}

echo '</pre>';
?>